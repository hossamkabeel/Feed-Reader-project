# Project Overview

In my nanodegree course. There is a project using jasmine to test the javascript application and make sure it works correctly.

## Why this Project?

In this project I learn very important skill, Not only do I write the project code, but I have to write a special code to test the project. and that is required in the labor market to that the project is well done.


## What will I learn?

I will learn How to use jasmine to test my project and make sure it works correctly.


## How will this help my career?

This is important skill when joining a new company.


# How will I complete this project?

1. Read all elements required in the FeedReader project from Project Details.
2. Download the project from (https://github.com/udacity/frontend-nanodegree-feedreader).
3. Open project files by Atom program to explore and edit it. I modified feedreader.js file.
4. View index.html file in google chrome browser.
5. The following tests were performed to implement the required:
    * Tests for allfeeds has been defined and that it is not empty.
    * Tests for allFeeds have a url and that the url is not empty.
    * Tests for allFeeds have a name and that the name is not empty.
    * Searches for the class of 'menu-hidden' in the body tag and checks that the menu is hidden.
    * Toggles on click event if the menu appears or disappears.
    * Tests if the loadFeed function has at least a single '.entry' within the '.feed' container.
    * Tests to see if two entries are not equal.

Thanks.
Hossam Kabeel
hossamkabeel@gmail.com
